package com.example.proiectandroid.repository;

import android.content.Context;
import android.os.AsyncTask;

import com.example.proiectandroid.ApplicationController;
import com.example.proiectandroid.database.AppDatabase;
import com.example.proiectandroid.listener.OnUserRepositoryActionListener;
import com.example.proiectandroid.models.User;

public class UserRepository {

    private final AppDatabase appDatabase;

    public UserRepository(Context context) {
        appDatabase = ApplicationController.getAppDatabase();
    }

    public void insertTask(final User user, final OnUserRepositoryActionListener listener) {
        new InsertTask(listener).execute(user);
    }

    public User getUserByEmail(String email){
        return appDatabase.userDao().findByEmail(email);
    }


    private class InsertTask extends AsyncTask<User, Void, Void> {

        OnUserRepositoryActionListener listener;

        InsertTask(OnUserRepositoryActionListener listener) {
            this.listener = listener;
        }

        @Override

        protected Void doInBackground(User... users) {
            appDatabase.userDao().insertAll(users[0]);
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            listener.actionSuccess();
        }

    }

}