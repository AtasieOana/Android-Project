package com.example.proiectandroid.listener;

public interface OnUserRepositoryActionListener {

    void actionSuccess();

    void actionFailed();

}